import maya.cmds as cmds
import pymel.core as pm

from ... import utils, module

class FingersIK(module.Module) :
	def __init__(self, name):
		super(self.__class__, self).__init__()

		self.name = name
		self.type = __name__.split('.')[-1]
		self.unic = False
		self.main = None
		self.w = None
		
	def connect(self, target, opposite=False):
		super(self.__class__, self).connect(target, opposite)

		targetModuleName = utils.getModuleName(target)
		target_module = utils.getModuleInstance(targetModuleName)
		
		target_modType = utils.getModuleTypeFromAttr(target)
		if target_modType == 'limb':
			cmds.delete(self.name+"_root_connector_multMat")
			cmds.pointConstraint(self.name+"_root_ik_out", targetModuleName+"_ik_connector", mo=0)
			cmds.parentConstraint(targetModuleName+"_ik_out", self.name+"_ik_connector", mo=0)
			cmds.parentConstraint(targetModuleName+"_fk_out", self.name+"_fk_connector", mo=0)
			cmds.connectAttr(targetModuleName+"_control.ikFk", self.name+"_mod.ikFk")
			cmds.connectAttr(targetModuleName+"_outJoints.s", self.name+"_root_connector.s")

			if target_module.isOpposite():
				cmds.setAttr(self.name+"_root_connector.rx", 180)

			cmds.select(clear=1)

		if opposite:
			# соединяем closed и spread
			opp_name = utils.getOpposite(self.name)
			for f in ["thumb", "index", "middle", "ring", "pinky"]:
				for i in range(1, 4):
					cmds.connectAttr(f"{opp_name}_{f}Finger_{i}_closed.t", f"{self.name}_{f}Finger_{i}_closed.t")
					cmds.connectAttr(f"{opp_name}_{f}Finger_{i}_closed.r", f"{self.name}_{f}Finger_{i}_closed.r")
					cmds.connectAttr(f"{opp_name}_{f}Finger_{i}_closed.s", f"{self.name}_{f}Finger_{i}_closed.s")
				cmds.connectAttr(f"{opp_name}_{f}Finger_1_spread.t", f"{self.name}_{f}Finger_1_spread.t")
				cmds.connectAttr(f"{opp_name}_{f}Finger_1_spread.r", f"{self.name}_{f}Finger_1_spread.r")
				cmds.connectAttr(f"{opp_name}_{f}Finger_1_spread.s", f"{self.name}_{f}Finger_1_spread.s")

		if target_modType == 'limb':			
			self.makeSeamless(True)
		
	def disconnect(self):
		out_nodes = pm.PyNode( self.name+"_root_ik_out").outputs()
		if out_nodes:
			con = out_nodes[0]
			in_node = con.outputs()[0]
			pm.delete(con)
			in_node.t.set(0,0,0)
		super(self.__class__, self).disconnect()
		
	

	def connectSignals(self, mainInstance, w):
		self.w = w
		self.main = mainInstance
			
	def rebuild(self):
		module = self.main.curModule
			
	def updateOptionsPage(self, w):
		pass

	def getData(self):
		data = super(self.__class__, self).getData()
		
		optionsData = {}
		
		data['optionsData'] = optionsData	

		return data	
	
	def setOptions(self, options):
		name = self.name
		opp_name = utils.getOpposite(self.name)
